<?php
// returns {"products":10,"suppliers":3}
echo json_encode(array("products" => 10, "suppliers" => 3));
?>